const AWS = require('aws-sdk');
const s3 = new AWS.S3();

exports.handler = async (event) => {
  const now = new Date();
  const fileName = `gerado-${now.toISOString()}.txt`;
  
  await s3.putObject({
    Bucket: process.env.BUCKET_NAME,
    Key: fileName,
    Body: `Arquivo gerado em: ${now.toISOString()}`
  }).promise();

  return { status: "success", fileName };
};